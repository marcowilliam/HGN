<html>
<head>
	<title> Login - Highest Good Network </title>
	<link href="styles/index.css" rel="stylesheet">
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300,100' rel='stylesheet' type='text/css'>
	<link rel="icon" type="image/png" href="img/favicon.png"/>
</head>

<body>
	<a href="http://www.onecommunityglobal.org" target="_blank"> <img src="img/Logo.jpg"> </a>

	<!-- LOGO AQUI -->

	<section class="main">
			<form class="form-1" action="resetPassword.php" method="POST">
				<h2 class = "type"> Type your email here </h2>
				<p class="field">
					<input type="text" name="email" placeholder="Email">
				<i class="fa fa-user fa-lg"></i>
			</p>
			<p class="submit">
				<button type="submit" name="submit"><i class="fa fa-arrow-right fa-2x"></i></button>
			</p>
		</form>
	</section>

</body>
</html>