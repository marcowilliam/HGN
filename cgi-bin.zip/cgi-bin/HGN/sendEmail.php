<?php

$headers = 'From: <webmasterACE@webmasterACE.com>' . "\r\n";

mail($to, $subject, $message, $headers);

// JUST FOR NOW

//echo "<script> alert('Password successfully changed to " . $password_new . ", check your email.'); </script>";

?>